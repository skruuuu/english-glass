CREATE TABLE `attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`lesson_id` text NOT NULL,
	`skill` text NOT NULL,
	`score` integer NOT NULL,
	`feedback` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `attempts_user_time` ON `attempts` (`user_id`,`created_at`);