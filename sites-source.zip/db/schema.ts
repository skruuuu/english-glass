import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const attempts=sqliteTable('attempts',{
 id:text('id').primaryKey(),userId:text('user_id').notNull(),lessonId:text('lesson_id').notNull(),skill:text('skill').notNull(),score:integer('score').notNull(),feedback:text('feedback').notNull(),createdAt:integer('created_at').notNull(),
},t=>[index('attempts_user_time').on(t.userId,t.createdAt)]);
