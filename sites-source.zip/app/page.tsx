import LearningApp from './learning-app';
import {getChatGPTUser,chatGPTSignInPath,chatGPTSignOutPath} from './chatgpt-auth';
export const dynamic='force-dynamic';
export default async function Page(){const user=await getChatGPTUser();return <LearningApp signedIn={!!user} signIn={chatGPTSignInPath('/')} signOut={chatGPTSignOutPath('/')}/>}
