import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = { title: "English Glass", description: "Listening, Speaking, Reading, Writing.", icons: { icon: "/favicon.svg" } };

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
