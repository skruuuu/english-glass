import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
export const dynamic='force-dynamic';
export async function GET(){const user=await getChatGPTUser();if(!user)return Response.json({error:'Sign in required'},{status:401});if(!env.DB)return Response.json({error:'History unavailable'},{status:503});try{const {results}=await env.DB.prepare('SELECT id,lesson_id AS lessonId,skill,score,feedback,created_at AS createdAt FROM attempts WHERE user_id=? ORDER BY created_at DESC LIMIT 200').bind(user.userId).all();return Response.json({attempts:results},{headers:{'Cache-Control':'no-store'}})}catch{return Response.json({error:'履歴を読み込めませんでした。再試行してください。'},{status:503})}}
