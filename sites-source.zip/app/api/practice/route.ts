import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {lessons,grade} from '../../../lib/lessons';
import {validateSubmission} from '../../../lib/validation';
export const dynamic='force-dynamic';
export async function POST(request:Request){
 const origin=request.headers.get('origin');if(origin!==new URL(request.url).origin)return Response.json({error:'Invalid origin'},{status:403});
 const user=await getChatGPTUser();if(!user)return Response.json({error:'ログインしてください。'},{status:401});
 if(Number(request.headers.get('content-length'))>12000)return Response.json({error:'回答が長すぎます。'},{status:413});
 let rawBody:unknown;try{const raw=await request.text();if(raw.length>12000)throw Error();rawBody=JSON.parse(raw)}catch{return Response.json({error:'Invalid request'},{status:400})}
 const body=validateSubmission(rawBody);const lesson=body&&lessons.find(l=>l.id===body.lessonId);if(!body||!lesson)return Response.json({error:'回答を確認してください。'},{status:400});
 if(!env.DB)return Response.json({error:'保存先に接続できません。再試行してください。'},{status:503});
 const result=grade(lesson,body.answer);try{
  const existing=await env.DB.prepare('SELECT user_id AS userId,lesson_id AS lessonId,score,feedback,created_at AS createdAt FROM attempts WHERE id=?').bind(body.requestId).first<{userId:string;lessonId:string;score:number;feedback:string;createdAt:number}>();if(existing){if(existing.userId!==user.userId||existing.lessonId!==lesson.id)return Response.json({error:'もう一度お試しください。'},{status:409});return Response.json({score:existing.score,correct:existing.score===100,feedback:existing.feedback,reference:lesson.answer,saved:true,id:body.requestId,createdAt:existing.createdAt,feedbackMode:'reference'},{headers:{'Cache-Control':'no-store'}})}
  const createdAt=Date.now();await env.DB.prepare('INSERT OR IGNORE INTO attempts(id,user_id,lesson_id,skill,score,feedback,created_at) VALUES (?,?,?,?,?,?,?)').bind(body.requestId,user.userId,lesson.id,lesson.skill,result.score,result.feedback,createdAt).run();
  return Response.json({...result,saved:true,id:body.requestId,createdAt,feedbackMode:'reference'},{headers:{'Cache-Control':'no-store'}});
 }catch{return Response.json({error:'保存できませんでした。もう一度お試しください。'},{status:503})}
}
