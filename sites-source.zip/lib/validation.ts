export function validateSubmission(value:unknown):{lessonId:string;answer:string;requestId:string}|null{
 if(!value||typeof value!=='object')return null;
 const b=value as Record<string,unknown>;
 if(typeof b.lessonId!=='string'||typeof b.answer!=='string'||!b.answer.trim()||b.answer.length>2000||typeof b.requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(b.requestId))return null;
 return {lessonId:b.lessonId,answer:b.answer,requestId:b.requestId};
}
